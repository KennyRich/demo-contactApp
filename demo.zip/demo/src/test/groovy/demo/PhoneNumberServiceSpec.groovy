package demo

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class PhoneNumberServiceSpec extends Specification implements ServiceUnitTest<PhoneNumberService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
