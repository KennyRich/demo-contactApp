package demo

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class EmailControllerSpec extends Specification implements ControllerUnitTest<EmailController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
