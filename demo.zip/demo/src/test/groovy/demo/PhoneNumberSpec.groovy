package demo

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class PhoneNumberSpec extends Specification implements DomainUnitTest<PhoneNumber> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
