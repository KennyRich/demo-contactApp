package demo

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class AddressControllerSpec extends Specification implements ControllerUnitTest<AddressController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
