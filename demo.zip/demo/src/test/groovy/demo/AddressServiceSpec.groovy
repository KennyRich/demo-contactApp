package demo

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class AddressServiceSpec extends Specification implements ServiceUnitTest<AddressService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
